﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System;
using System.Collections.Generic;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CajeroDAL.Cajerodal
{
  

  
        public class TarjetaDAL
        {
            private static string conexion = "Server=localhost;Database=CajeroDB;Uid=root;Pwd=123a;";

            // Obtener todas las tarjetas
            public List<Tarjeta> ObtenerTarjetas()
            {
                List<Tarjeta> tarjetas = new List<Tarjeta>();

                using (MySqlConnection conn = new MySqlConnection(conexion))
                {
                    conn.Open();
                    string query = "SELECT * FROM Tarjeta";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            tarjetas.Add(new Tarjeta
                            {
                                TarjetaID = reader.GetInt32("TarjetaID"),
                                CuentaID = reader.GetInt32("CuentaID"),
                                NumeroTarjeta = reader.GetString("NumeroTarjeta"),
                                CVV = reader.GetString("CVV"),
                                FechaExpiracion = reader.GetDateTime("FechaExpiracion"),
                                PINHash = reader.GetString("PINHash"),
                                Estado = reader.GetInt32("Estado")
                            });
                        }
                    }
                }

                return tarjetas;
            }


        public List<Tarjeta> buscarTarjetas(string cadena)
        {
            List<Tarjeta> tarjetas = new List<Tarjeta>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM tarjeta WHERE NumeroTarjeta LIKE '" + cadena + "%'";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tarjetas.Add(new Tarjeta
                        {
                            TarjetaID = reader.GetInt32("TarjetaID"),
                            CuentaID = reader.GetInt32("CuentaID"),
                            NumeroTarjeta = reader.GetString("NumeroTarjeta"),
                            CVV = reader.GetString("CVV"),
                            FechaExpiracion = reader.GetDateTime("FechaExpiracion"),
                            PINHash = reader.GetString("PINHash"),
                            Estado = reader.GetInt32("Estado")
                        });
                    }
                }
            }

            return tarjetas;
        }
 


        // Insertar tarjeta
        public void InsertarTarjeta(Tarjeta tarjeta)
            {
                using (MySqlConnection conn = new MySqlConnection(conexion))
                {
                    conn.Open();
                    string query = "INSERT INTO Tarjeta (CuentaID, NumeroTarjeta, CVV, FechaExpiracion, PINHash, Estado) " +
                                   "VALUES (@CuentaID, @NumeroTarjeta, @CVV, @FechaExpiracion, @PINHash, @Estado)";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CuentaID", tarjeta.CuentaID);
                    cmd.Parameters.AddWithValue("@NumeroTarjeta", tarjeta.NumeroTarjeta);
                    cmd.Parameters.AddWithValue("@CVV", tarjeta.CVV);
                    cmd.Parameters.AddWithValue("@FechaExpiracion", tarjeta.FechaExpiracion);
                    cmd.Parameters.AddWithValue("@PINHash", tarjeta.PINHash);
                    cmd.Parameters.AddWithValue("@Estado", tarjeta.Estado);
                    cmd.ExecuteNonQuery();
                }
            }

            // Actualizar tarjeta
            public void ActualizarTarjeta(Tarjeta tarjeta)
            {
                using (MySqlConnection conn = new MySqlConnection(conexion))
                {
                    conn.Open();
                    string query = "UPDATE Tarjeta SET CVV=@CVV, FechaExpiracion=@FechaExpiracion, " +
                                   "PINHash=@PINHash, Estado=@Estado WHERE TarjetaID=@TarjetaID";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CVV", tarjeta.CVV);
                    cmd.Parameters.AddWithValue("@FechaExpiracion", tarjeta.FechaExpiracion);
                    cmd.Parameters.AddWithValue("@PINHash", tarjeta.PINHash);
                    cmd.Parameters.AddWithValue("@Estado", tarjeta.Estado);
                    cmd.Parameters.AddWithValue("@TarjetaID", tarjeta.TarjetaID);
                    cmd.ExecuteNonQuery();
                }
            }

            // Eliminar tarjeta
            public void EliminarTarjeta(int tarjetaID)
            {
                using (MySqlConnection conn = new MySqlConnection(conexion))
                {
                    conn.Open();
                    string query = "DELETE FROM Tarjeta WHERE TarjetaID=@TarjetaID";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TarjetaID", tarjetaID);
                    cmd.ExecuteNonQuery();
                }
            }

        public bool ValidarLogin(string numeroTarjeta, string pin)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Tarjeta WHERE NumeroTarjeta = @numeroTarjeta AND CVV = @pin";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@numeroTarjeta", numeroTarjeta);
                    cmd.Parameters.AddWithValue("@pin", pin);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    return count > 0; // true si se encontró una coincidencia
                }
            }
        }
   

    }
}


