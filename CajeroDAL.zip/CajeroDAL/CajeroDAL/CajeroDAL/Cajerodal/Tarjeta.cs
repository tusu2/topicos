﻿namespace CajeroDAL.Cajerodal
{
        public class Tarjeta
        {
            public int TarjetaID { get; set; }
            public int CuentaID { get; set; }
            public string NumeroTarjeta { get; set; }
            public string CVV { get; set; }
            public DateTime FechaExpiracion { get; set; }
            public string PINHash { get; set; }
            public int Estado { get; set; }
        }
    

}
