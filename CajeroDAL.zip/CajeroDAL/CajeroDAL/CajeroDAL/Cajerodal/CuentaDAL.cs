﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace CajeroDAL.Cajerodal
{
    public class CuentaDAL
    {
        private static string conexion = "Server=localhost;Database=CajeroDB;Uid=root;Pwd=123a;";

        // Obtener todas las cuentas
        public List<Cuenta> ObtenerCuentas()
        {
            List<Cuenta> cuentas = new List<Cuenta>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM Cuenta";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Cuenta cuenta = new Cuenta
                        {
                            CuentaID = reader.GetInt32("CuentaID"),
                            ClienteID = reader.GetInt32("ClienteID"),
                            ClaveBancaria = reader.GetString("ClaveBancaria"),
                            TipoCuenta = reader.GetString("TipoCuenta"),
                            Saldo = reader.GetDecimal("Saldo"),
                            FechaApertura = reader.GetDateTime("FechaApertura")
                        };
                        cuentas.Add(cuenta);
                    }
                }
            }

            return cuentas;
        }

        public List<Cuenta> buscarCuentas(string cadena)
        {
            List<Cuenta> cuentas = new List<Cuenta>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM Cuenta WHERE ClaveBancaria LIKE '" + cadena + "%'";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Cuenta cuenta = new Cuenta
                        {
                            CuentaID = reader.GetInt32("CuentaID"),
                            ClienteID = reader.GetInt32("ClienteID"),
                            ClaveBancaria = reader.GetString("ClaveBancaria"),
                            TipoCuenta = reader.GetString("TipoCuenta"),
                            Saldo = reader.GetDecimal("Saldo"),
                            FechaApertura = reader.GetDateTime("FechaApertura")
                        };
                        cuentas.Add(cuenta);
                    }
                }
            }

            return cuentas;
        }




        // Insertar nueva cuenta
        public void InsertarCuenta(Cuenta cuenta)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "INSERT INTO Cuenta (ClienteID, ClaveBancaria, TipoCuenta, Saldo) " +
                               "VALUES (@ClienteID, @ClaveBancaria, @TipoCuenta, @Saldo)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClienteID", cuenta.ClienteID);
                cmd.Parameters.AddWithValue("@ClaveBancaria", cuenta.ClaveBancaria);
                cmd.Parameters.AddWithValue("@TipoCuenta", cuenta.TipoCuenta);
                cmd.Parameters.AddWithValue("@Saldo", cuenta.Saldo);
                cmd.ExecuteNonQuery();
            }
        }

        // Actualizar cuenta
        public void ActualizarCuenta(Cuenta cuenta)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "UPDATE Cuenta SET TipoCuenta=@TipoCuenta, Saldo=@Saldo, " +
                    "ClienteID=@ClienteID, FechaApertura=@FechaApertura WHERE CuentaID=@CuentaID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@TipoCuenta", cuenta.TipoCuenta);
                cmd.Parameters.AddWithValue("@Saldo", cuenta.Saldo);
                cmd.Parameters.AddWithValue("@ClienteID", cuenta.ClienteID);
                cmd.Parameters.AddWithValue("@FechaApertura", cuenta.FechaApertura);
                cmd.Parameters.AddWithValue("@CuentaID", cuenta.CuentaID);
                cmd.ExecuteNonQuery();
            }
        }

        // Eliminar cuenta
        public void EliminarCuenta(int cuentaID)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "DELETE FROM Cuenta WHERE CuentaID=@CuentaID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CuentaID", cuentaID);
                cmd.ExecuteNonQuery();
            }
        }

        // Obtener saldo de una cuenta específica
        public decimal ObtenerSaldo(int cuentaID)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT Saldo FROM Cuenta WHERE CuentaID=@CuentaID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CuentaID", cuentaID);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToDecimal(result) : 0;
            }
        }

        // Actualizar solo saldo
        public void ActualizarSaldo(int cuentaID, decimal nuevoSaldo)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "UPDATE Cuenta SET Saldo=@Saldo WHERE CuentaID=@CuentaID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Saldo", nuevoSaldo);
                cmd.Parameters.AddWithValue("@CuentaID", cuentaID);
                cmd.ExecuteNonQuery();
            }
        }
        public int Obtenerid(string Tarjeta)
        {
            int IdCuenta = 0;

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT CuentaID FROM tarjeta WHERE NumeroTarjeta = @tarjeta";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@tarjeta", Tarjeta); // ✅ Evita inyección SQL

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) // ✅ Esto es obligatorio
                    {
                        IdCuenta = reader.GetInt32("CuentaID");
                    }
                }
            }

            return IdCuenta;
        }
        public int ObtenerClienteClave(string Clave)
        {

            int ClienteId = 0;
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT ClienteID FROM cuenta where ClaveBancaria ='" + Clave + "'";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        ClienteId = reader.GetInt32("ClienteID");

                        return ClienteId;

                    }
                }
            }
            return ClienteId;


        }


    }
}
