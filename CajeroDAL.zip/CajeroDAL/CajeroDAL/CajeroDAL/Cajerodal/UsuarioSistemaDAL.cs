﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace CajeroDAL.Cajerodal
{
    public class UsuarioSistemaDAL
    {
        private static string conexion = "Server=localhost;Database=CajeroDB;Uid=root;Pwd=123a;";

        // Obtener todos los usuarios del sistema
        public List<UsuarioSistema> ObtenerUsuarios()
        {
            List<UsuarioSistema> usuarios = new List<UsuarioSistema>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM UsuarioSistema";
                MySqlCommand cmd = new MySqlCommand(query, conn);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        usuarios.Add(new UsuarioSistema
                        {
                            UsuarioID = reader.GetInt32("UsuarioID"),
                            Nombre = reader.GetString("Nombre"),
                            Usuario = reader.GetString("Usuario"),
                            Contraseña = reader.GetString("Contraseña"),
                            Rol = reader.GetString("Rol"),
                            Estado = reader.GetString("Estado")
                        });
                        conn.Close();
                    }
                }
            }

            return usuarios;

        }

        // Insertar usuario
        public void InsertarUsuario(UsuarioSistema usuario)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "INSERT INTO UsuarioSistema (Nombre, Usuario, Contraseña, Rol) " +
                               "VALUES (@Nombre, @Usuario  @Contraseña, @Rol)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", usuario.Nombre);
                cmd.Parameters.AddWithValue("@Usuario", usuario.Usuario);
                cmd.Parameters.AddWithValue("@Contraseña", usuario.Contraseña);
                cmd.Parameters.AddWithValue("@Rol", usuario.Rol);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        // Actualizar usuario
        public void ActualizarUsuario(UsuarioSistema usuario)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "UPDATE UsuarioSistema SET Nombre=@Nombre, Usuario=@Usuario, Contraseña=@Contraseña, Rol=@Rol, Estado=@Estado  WHERE UsuarioID=@UsuarioID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", usuario.Rol);
                cmd.Parameters.AddWithValue("@Usuario", usuario.Rol);
                cmd.Parameters.AddWithValue("@Contraseña", usuario.Contraseña);
                cmd.Parameters.AddWithValue("@Rol", usuario.Rol);
                cmd.Parameters.AddWithValue("@Estado", usuario.Rol);
                cmd.Parameters.AddWithValue("@UsuarioID", usuario.UsuarioID);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        // Eliminar usuario
        public void EliminarUsuario(int usuarioID)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "DELETE FROM UsuarioSistema WHERE UsuarioID=@UsuarioID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UsuarioID", usuarioID);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        // Validar inicio de sesión
        public UsuarioSistema ValidarLogin(string nombreUsuario, string passwordHash)
        {
            UsuarioSistema usuario = null;

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM usuariosistema WHERE usuario = @usuario AND contraseña = @contraseña";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@usuario", nombreUsuario);
                cmd.Parameters.AddWithValue("@contraseña", passwordHash);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        usuario = new UsuarioSistema
                        {
                            UsuarioID = reader.GetInt32("UsuarioID"),
                            Nombre = reader.GetString("nombre"),
                            Usuario = reader.GetString("usuario"),
                            Contraseña = reader.GetString("contraseña"),
                            Estado = reader.GetString("Estado"),
                            Rol = reader.GetString("Rol")
                        };
                    }
                }
            }

            return usuario;
        }
    }
}
