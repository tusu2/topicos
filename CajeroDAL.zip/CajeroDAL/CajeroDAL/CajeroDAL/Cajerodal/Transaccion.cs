﻿namespace CajeroDAL.Cajerodal
{
    public class Transaccion
    {
        public int TransaccionID { get; set; }
        public int CuentaOrigenID { get; set; }
        public int? CuentaDestinoID { get; set; }  // nullable para depósitos y retiros
        public string Tipo { get; set; }           // Retiro, Deposito, Transferencia
        public decimal Monto { get; set; }
        public DateTime FechaHora { get; set; }
        public string Descripcion { get; set; }
    }
}
