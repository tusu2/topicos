﻿namespace CajeroDAL.Cajerodal
{
    public class Cuenta
    {
        public int CuentaID { get; set; }
        public int ClienteID { get; set; }
        public string ClaveBancaria { get; set; }
        public string TipoCuenta { get; set; }
        public decimal Saldo { get; set; }
        public DateTime FechaApertura { get; set; }
    }
}
