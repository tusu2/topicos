﻿using System;
using System.Collections.Generic;
using System.Data;
using CajeroDAL.Cajerodal;
using MySql.Data.MySqlClient;

namespace CajeroDAL.Cajerodal
{
    public class HistorialTransaccionDAL
    {
        private static string connectionString = "Server=localhost;Database=CajeroDB;Uid=root;Pwd=1;";

        public void Agregar(HistorialTransaccion transaccion)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                string query = @"INSERT INTO historialtransaccion (CuentaID, Tipo, Monto, FechaHora, Descripcion, ClaveBancariaD)
                             VALUES (@CuentaID, @Tipo, @Monto, @FechaHora, @Descripcion, @ClaveBancariaD)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CuentaID", transaccion.CuentaID);
                cmd.Parameters.AddWithValue("@Tipo", transaccion.Tipo);
                cmd.Parameters.AddWithValue("@Monto", transaccion.Monto);
                cmd.Parameters.AddWithValue("@FechaHora", transaccion.FechaHora);
                cmd.Parameters.AddWithValue("@Descripcion", transaccion.Descripcion ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ClaveBancariaD", transaccion.ClaveBancariaD ?? (object)DBNull.Value);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Editar(HistorialTransaccion transaccion)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                string query = @"UPDATE historialtransaccion
                             SET CuentaID = @CuentaID, Tipo = @Tipo, Monto = @Monto,
                                 FechaHora = @FechaHora, Descripcion = @Descripcion, ClaveBancariaD = @ClaveBancariaD
                             WHERE HistorialID = @HistorialID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CuentaID", transaccion.CuentaID);
                cmd.Parameters.AddWithValue("@Tipo", transaccion.Tipo);
                cmd.Parameters.AddWithValue("@Monto", transaccion.Monto);
                cmd.Parameters.AddWithValue("@FechaHora", transaccion.FechaHora);
                cmd.Parameters.AddWithValue("@Descripcion", transaccion.Descripcion ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ClaveBancariaD", transaccion.ClaveBancariaD ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@HistorialID", transaccion.HistorialID);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Eliminar(int historialID)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                string query = "DELETE FROM historialtransaccion WHERE HistorialID = @HistorialID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@HistorialID", historialID);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<HistorialTransaccion> MostrarPorCuentaID(int cuentaID)
        {
            List<HistorialTransaccion> lista = new List<HistorialTransaccion>();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                string query = "SELECT * FROM historialtransaccion WHERE CuentaID = @CuentaID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CuentaID", cuentaID);

                conn.Open();
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        lista.Add(new HistorialTransaccion
                        {
                            HistorialID = reader.GetInt32("HistorialID"),
                            CuentaID = reader.GetInt32("CuentaID"),
                            Tipo = reader.GetString("Tipo"),
                            Monto = reader.GetDecimal("Monto"),
                            FechaHora = reader.GetDateTime("FechaHora"),
                            Descripcion = reader.GetString("Descripcion"),
                            ClaveBancariaD = reader.GetString("ClaveBancariaD")

                        });
                    }
                }
            }

            return lista;
        }

    }


}
