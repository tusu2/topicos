﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroDAL.Cajerodal
{
    public class HistorialTransaccion
    {
        public int HistorialID { get; set; }
        public int CuentaID { get; set; }
        public string Tipo { get; set; }
        public decimal Monto { get; set; }
        public DateTime FechaHora { get; set; }
        public string Descripcion { get; set; }
        public string ClaveBancariaD { get; set; }
    }
}
