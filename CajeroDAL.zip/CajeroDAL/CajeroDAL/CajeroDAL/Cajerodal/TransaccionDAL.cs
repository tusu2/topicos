﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace CajeroDAL.Cajerodal
{
    public class TransaccionDAL
    {
        private static string conexion = "Server=localhost;Database=CajeroDB;Uid=root;Pwd=1;";

        // Obtener todas las transacciones
        public List<Transaccion> ObtenerTransacciones()
        {
            List<Transaccion> transacciones = new List<Transaccion>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM Transaccion";
                MySqlCommand cmd = new MySqlCommand(query, conn);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        transacciones.Add(new Transaccion
                        {
                            TransaccionID = reader.GetInt32("TransaccionID"),
                            CuentaOrigenID = reader.GetInt32("CuentaOrigenID"),
                            CuentaDestinoID = reader.IsDBNull(reader.GetOrdinal("CuentaDestinoID")) ? (int?)null : reader.GetInt32("CuentaDestinoID"),
                            Tipo = reader.GetString("Tipo"),
                            Monto = reader.GetDecimal("Monto"),
                            FechaHora = reader.GetDateTime("FechaHora"),
                            Descripcion = reader.IsDBNull(reader.GetOrdinal("Descripcion")) ? null : reader.GetString("Descripcion")
                        });
                    }
                }
            }

            return transacciones;
        }

        // Insertar nueva transacción
        public void InsertarTransaccion(Transaccion transaccion)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = @"INSERT INTO Transaccion (CuentaOrigenID, CuentaDestinoID, Tipo, Monto, FechaHora, Descripcion)
                                 VALUES (@CuentaOrigenID, @CuentaDestinoID, @Tipo, @Monto, @FechaHora, @Descripcion)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CuentaOrigenID", transaccion.CuentaOrigenID);
                cmd.Parameters.AddWithValue("@CuentaDestinoID", (object)transaccion.CuentaDestinoID ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Tipo", transaccion.Tipo);
                cmd.Parameters.AddWithValue("@Monto", transaccion.Monto);
                cmd.Parameters.AddWithValue("@FechaHora", transaccion.FechaHora);
                cmd.Parameters.AddWithValue("@Descripcion", transaccion.Descripcion);
                cmd.ExecuteNonQuery();
            }
        }

        // Eliminar transacción (opcional si lo deseas)
        public void EliminarTransaccion(int transaccionID)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "DELETE FROM Transaccion WHERE TransaccionID = @TransaccionID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@TransaccionID", transaccionID);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
