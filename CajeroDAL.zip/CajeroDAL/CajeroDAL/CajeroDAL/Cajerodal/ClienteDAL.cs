﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System;
using System.Collections.Generic;

namespace CajeroDAL.Cajerodal
{
    public class ClienteDAL
    {
        private static string conexion = "Server=localhost;Database=CajeroDB;Uid=root;Pwd=123a;";

        // Obtener todos los clientes
        public List<Cliente> ObtenerClientes()
        {
            List<Cliente> clientes = new List<Cliente>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM Cliente";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        clientes.Add(new Cliente
                        {
                            ClienteID = reader.GetInt32("ClienteID"),
                            Nombre = reader.GetString("Nombre"),
                            Apellidos = reader.GetString("Apellidos"),
                            Celular = reader.IsDBNull(reader.GetOrdinal("Celular")) ? null : reader.GetString("Celular"),
                            Email = reader.IsDBNull(reader.GetOrdinal("Email")) ? null : reader.GetString("Email"),
                            Direccion = reader.IsDBNull(reader.GetOrdinal("Direccion")) ? null : reader.GetString("Direccion")
                        });
                    }
                }
            }

            return clientes;
        }

        public List<Cliente> buscarClientes(string Cadena)
        {
            List<Cliente> clientes = new List<Cliente>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM cliente WHERE Nombre LIKE '" + Cadena + "%'";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {

                    while (reader.Read())
                    {
                        clientes.Add(new Cliente
                        {
                            ClienteID = reader.GetInt32("ClienteID"),
                            Nombre = reader.GetString("Nombre"),
                            Apellidos = reader.GetString("Apellidos"),
                            Celular = reader.IsDBNull(reader.GetOrdinal("Celular")) ? null : reader.GetString("Celular"),
                            Email = reader.IsDBNull(reader.GetOrdinal("Email")) ? null : reader.GetString("Email"),
                            Direccion = reader.IsDBNull(reader.GetOrdinal("Direccion")) ? null : reader.GetString("Direccion")
                        });
                    }
                }
            }
            return clientes;
        }

        // Insertar cliente
        public void InsertarCliente(Cliente cliente)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "INSERT INTO Cliente (Nombre, Apellidos, Celular, Email, Direccion) " +
                               "VALUES (@Nombre, @Apellidos, @Celular, @Email, @Direccion)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                cmd.Parameters.AddWithValue("@Apellidos", cliente.Apellidos);
                cmd.Parameters.AddWithValue("@Celular", cliente.Celular);
                cmd.Parameters.AddWithValue("@Email", cliente.Email);
                cmd.Parameters.AddWithValue("@Direccion", cliente.Direccion);
                cmd.ExecuteNonQuery();
            }
        }

        // Actualizar cliente
        public void ActualizarCliente(Cliente cliente)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "UPDATE Cliente SET Nombre=@Nombre, Apellidos=@Apellidos, Celular=@Celular, " +
                               "Email=@Email, Direccion=@Direccion WHERE ClienteID=@ClienteID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                cmd.Parameters.AddWithValue("@Apellidos", cliente.Apellidos);
                cmd.Parameters.AddWithValue("@Celular", cliente.Celular);
                cmd.Parameters.AddWithValue("@Email", cliente.Email);
                cmd.Parameters.AddWithValue("@Direccion", cliente.Direccion);
                cmd.Parameters.AddWithValue("@ClienteID", cliente.ClienteID);
                cmd.ExecuteNonQuery();
            }
        }

        // Eliminar cliente
        public void EliminarCliente(int clienteID)
        {
            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "DELETE FROM Cliente WHERE ClienteID=@ClienteID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClienteID", clienteID);
                cmd.ExecuteNonQuery();
            }
        }

        public List<Cliente> ObtenerCliente(int id)
        {
            List<Cliente> clientes = new List<Cliente>();

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT * FROM Cliente where clienteid=" + id + "";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        clientes.Add(new Cliente
                        {
                            ClienteID = reader.GetInt32("ClienteID"),
                            Nombre = reader.GetString("Nombre"),
                            Apellidos = reader.GetString("Apellidos"),
                            Celular = reader.IsDBNull(reader.GetOrdinal("Celular")) ? null : reader.GetString("Celular"),
                            Email = reader.IsDBNull(reader.GetOrdinal("Email")) ? null : reader.GetString("Email"),
                            Direccion = reader.IsDBNull(reader.GetOrdinal("Direccion")) ? null : reader.GetString("Direccion")
                        });
                    }
                }
            }

            return clientes;
        }
        public int Obtenerid(string Tarjeta)
        {
            int IdCliente = 0;

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT c.ClienteID FROM tarjeta t JOIN cuenta c ON t.CuentaID = c.CuentaID WHERE t.NumeroTarjeta = @tarjeta";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@tarjeta", Tarjeta); // ✅ Protección contra inyección SQL

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) // ✅ Necesario antes de acceder a datos
                    {
                        IdCliente = reader.GetInt32("ClienteID");
                    }
                }
            }

            return IdCliente;
        }

        public int ObteneridClave(string Clave)
        {
            int IdCliente = 0;

            using (MySqlConnection conn = new MySqlConnection(conexion))
            {
                conn.Open();
                string query = "SELECT ClienteID FROM cajerodb.cuenta where claveBancaria=@Clave";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Clave", Clave); // ✅ Protección contra inyección SQL

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) // ✅ Necesario antes de acceder a datos
                    {
                        IdCliente = reader.GetInt32("ClienteID");
                    }
                }
            }

            return IdCliente;
        }



    }
}
